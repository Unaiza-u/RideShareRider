package com.example.ridesharerider.DirectionHelpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
